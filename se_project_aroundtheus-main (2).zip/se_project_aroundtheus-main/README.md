TripleTen Project 3 Around The U.S.A.

Project Description: This is my first responsive website and can by viewed through desktop and mobile devices.

Techniques: The techniques used here are with HTML, CSS, BEM and Media Queries. This is my first time using FIGMA.

Here is my GitHub page: https://marcus3278.github.io/Around-the-usa-/

Here is my Github repository: https://github.com/Marcus3278/SE-Project-Around-the-USA-

link to my video covering the project https://drive.google.com/file/d/15rVfz-rzkfzcBKP9qhMT-3IihqV66ZIF/view?usp=sharing


![Screenshot 2024-01-23 114338](https://github.com/Marcus3278/Around-the-usa-/assets/112821776/59adf6d7-d240-45d9-a388-62011ee42450)
